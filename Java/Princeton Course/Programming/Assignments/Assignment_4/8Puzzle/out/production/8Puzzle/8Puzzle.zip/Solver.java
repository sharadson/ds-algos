import edu.princeton.cs.algs4.MinPQ;
import java.util.ArrayList;

public class Solver {
    private SearchNode min;

    public Solver(Board initial)           // find a solution to the initial board (using the A* algorithm)
    {
        SearchNode root = new SearchNode(initial,null,0);
        MinPQ<SearchNode> minPQ = new MinPQ<>();
        minPQ.insert(root);
        min = minPQ.delMin();

      while (!min.board.isGoal()) {
        for (Board neighbour : min.board.neighbors()) {
          if (min.last == null || !neighbour.equals(min.last.board)){
              SearchNode neighbourNode = new SearchNode(neighbour, min, min.moves + 1);
              minPQ.insert(neighbourNode);
          }
        }
        min = minPQ.delMin();
      }
    }

    public boolean isSolvable()            // is the initial board solvable?
    {
      throw new UnsupportedOperationException();
    }

    public int moves()                     // min number of moves to solve initial board; -1 if unsolvable
    {
      return min.moves;
    }

    public Iterable<Board> solution()      // sequence of boards in a shortest solution; null if unsolvable
    {
      ArrayList<Board> sequence = new ArrayList<>();
      SearchNode traverse = min;
      while(traverse!=null){
        sequence.add(traverse.board);
        traverse=traverse.last;
      }

      int length = sequence.size();
      ArrayList<Board> result = new ArrayList<>(length);

      for (int i = length - 1; i >= 0; i--) {
        result.add(sequence.get(i));
      }
      return result;
    }

    private class SearchNode implements Comparable<SearchNode>{
      private final int manhattan;
      Board board;
      SearchNode last;
      int moves;

      public SearchNode(Board board, SearchNode last, int moves) {
        this.board = board;
        this.last = last;
        this.moves = moves;
        this.manhattan = board.manhattan();
      }

      @Override
      public int compareTo(SearchNode that) {
          return Integer.compare(this.manhattan +this.moves, that.manhattan +that.moves);

      }
    }

}