import edu.princeton.cs.algs4.StdRandom;

import java.util.Iterator;

public class RandomizedQueue<Item> implements Iterable<Item>{

  private Item[] queue;
  private int[] emptySpots;
  private int count;
  private int emptyCount;
  private int front;
  private int rear;

  public RandomizedQueue() {
    initialize();
  }

  private void initialize() {
    queue = (Item[]) new Object[2];
    emptySpots = new int[2];
    count = 0;
    emptyCount = 0;
    front = -1;
    rear = -1;
  }

  @Override
  public Iterator<Item> iterator() {
    return new ListIterator();
  }

  public boolean isEmpty() {
    return count == 0;
  }

  public void enqueue(Item i) {
    if(i == null) {
      throw new java.lang.IllegalArgumentException();
    }

    if (count == queue.length) {
      queue = resize(queue.length*2);
    }

    if(isEmpty()) {
      queue[0] = i;
      front = 0;
      rear = 0;
    }
    else {
      if (emptyCount > 0) {
        queue[emptySpots[emptyCount--]] = i;
      }
      else {
        if (isEmptyAtRearEnd()) {
          queue[++rear] = i;
        }
      }
      /*if (isEmptyAtFrontEnd()) {
        queue[--front] = i;
      }
      else {
        if (isEmptyAtRearEnd()) {
          queue[++rear] = i;
        }
      }*/
    }

    count++;

    if (emptySpots.length > 8 && emptyCount <= emptySpots.length/4) {
      emptySpots = resizeEmpty(emptySpots.length/2);
    }
  }

  private boolean isEmptyAtFrontEnd() {
    return front > 0;
  }

  private boolean isEmptyAtRearEnd() {
    return rear < queue.length - 1;
  }

  private Item[] resize(int newSize) {
    Item[] newQueue = (Item[]) new Object[newSize];
    for(int i=front; i <= rear; i++ ){
      if (queue[i] != null) {
        newQueue[i - front] = queue[i];
      }
    }
    front = 0;
    rear = count - 1;
    return newQueue;
  }

  private int[] resizeEmpty(int newSize) {
    int[] newQueue = new int[newSize];
    System.arraycopy(emptySpots, 0, newQueue, 0, emptySpots.length);
    return newQueue;
  }

  public int size() {
    return count;
  }

  public Item dequeue() {
    if(isEmpty()) {
      throw new java.util.NoSuchElementException();
    }
    int random = StdRandom.uniform(front, rear + 1);
    Item item = queue[random];
    while(item != null) {
      random = StdRandom.uniform(front, rear + 1);
      item = queue[random];
    }

    if(count == 1) {
      initialize();
    }
    if(count == 2) {
      if(front == random) {
        queue[front++] = null;
      }
      else {
        queue[rear--] = null;
      }
      count--;
    }
    if(count > 2) {
      if (emptyCount == emptySpots.length) {
        emptySpots = resizeEmpty(emptySpots.length*2);
      }
      emptySpots[emptyCount++] = random;
      queue[random] = null;
      //adjust(random);
      count--;
    }

    if (queue.length > 8 && count <= queue.length/4) {
      queue = resize(queue.length/2);
    }
    return item;
  }

  private void adjust(int random) {

    if (random - front < rear - random) {
      for (int i = random; i > front; i--) {
        queue[i] = queue[i - 1];
      }
      queue[front++] = null;
    } else {
      for (int i = random; i < rear; i++) {
        queue[i] = queue[i + 1];
      }
      queue[rear--] = null;
    }

  }

  public Item sample() {
    if(isEmpty()) {
      throw new java.util.NoSuchElementException();
    }
    int random = StdRandom.uniform(front, rear+1);
    return queue[random];
  }

  private class ListIterator implements Iterator<Item> {

    int current = 0;
    int[] randoms = new int[count];

    ListIterator() {
      if(count==0) return;
      for (int i =front; i<=rear; i++) {
        randoms[i-front] = i;
      }
      StdRandom.shuffle(randoms);
    }

    @Override
    public boolean hasNext() {
      return count > 0 && current < count;
    }

    @Override
    public Item next() {
      if(!hasNext()) {
        throw new java.util.NoSuchElementException();
      }
      int random = randoms[current++];
      return queue[random];
    }
  }
}
