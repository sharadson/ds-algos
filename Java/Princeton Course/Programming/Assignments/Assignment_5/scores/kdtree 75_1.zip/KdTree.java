import edu.princeton.cs.algs4.Point2D;
import edu.princeton.cs.algs4.RectHV;

import java.util.ArrayList;

public class KdTree {
  private Node root;
  private int count = 0;
  private boolean alternate = true;

  private static class Node {
    private Point2D point;      // the point
    private Node lb=null;        // the left/bottom subtree
    private Node rt=null;        // the right/top subtree
  }

  public KdTree() {                               // construct an empty set of points
  }

  public boolean isEmpty() {                      // is the set empty?
    return count == 0;
  }

  public int size() {                         // number of points in the set
    return count;
  }

  public void insert(Point2D p) {              // add the point to the set (if it is not already in the set)
    if (p == null) throw new IllegalArgumentException();
    if (contains(p)) return;
    alternate = true;
    root = insertNode(root, p);
    count++;
  }

  private Node insertNode(Node node, Point2D p) {
      if (node == null) {
        Node newNode = new Node();
        newNode.point = p;
        return newNode;
      }
      if (alternate) {
        insertTraverse(node, p, p.x(), node.point.x());
      }
      else {
        insertTraverse(node, p, p.y(), node.point.y());
      }
      return node;
  }

  private void insertTraverse(Node node, Point2D p, double pointCoordinate, double nodeCoordinate) {
    alternate = !alternate;
    if (pointCoordinate < nodeCoordinate) node.lb = insertNode(node.lb, p);
    else node.rt = insertNode(node.rt, p);
  }

  public boolean contains(Point2D p) {            // does the set contain point p?
    if (p == null) throw new IllegalArgumentException();
    if (isEmpty()) return false;

    alternate = true;
    return containsNode(root, p);
  }

  private boolean containsNode(Node node, Point2D p) {
    if (node == null) return false;
    if (p.equals(node.point)) return true;
    if (alternate) {
      alternate = false;
      return p.x() < node.point.x() ? containsNode(node.lb, p) : containsNode(node.rt, p);
    }
    else {
      alternate = true;
      return p.y() < node.point.y() ? containsNode(node.lb, p) : containsNode(node.rt, p);
    }
  }

  public void draw() {                         // draw all points to standard draw

  throw new UnsupportedOperationException();
  }

  public Iterable<Point2D> range(RectHV rect) {             // all points that are inside the rectangle (or on the boundary)
    if (rect == null) throw new IllegalArgumentException();
    ArrayList<Point2D> pointsInRange = new ArrayList<>();
    Node x = root;
    alternate = true;
    rectRange(x, rect, pointsInRange);
    return pointsInRange;
  }

  private void rectRange(Node node, RectHV rect, ArrayList<Point2D> rangePoints) {
    if (node == null) return;

    if (alternate) {
      rangeTraverse(node, rect, rangePoints, rect.xmax(), node.point.x(), rect.xmin());
    }
    else {
      rangeTraverse(node, rect, rangePoints, rect.ymax(), node.point.y(), rect.ymin());
    }

  }

  private void rangeTraverse(Node node, RectHV rect, ArrayList<Point2D> rangePoints, double rectMax, double nodeCoordinate, double rectMin) {
    alternate = !alternate;
    if (nodeCoordinate > rectMax) {
      rectRange(node.lb, rect, rangePoints);
    }
    else {
      if (nodeCoordinate < rectMin) {
        rectRange(node.rt, rect, rangePoints);
      }
      else {
        if (isNodeInRange(node, rect))
          rangePoints.add(node.point);

        rectRange(node.lb, rect, rangePoints);
        rectRange(node.rt, rect, rangePoints);
      }
    }
  }

  private boolean isNodeInRange(Node node, RectHV rect) {
    return node.point.x() >= rect.xmin()
            && node.point.x() <= rect.xmax()
            && node.point.y() >= rect.ymin()
            && node.point.y() <= rect.ymax();
  }

  public Point2D nearest(Point2D p) {             // a nearest neighbor in the set to point p; null if the set is empty
    if (p == null) throw new IllegalArgumentException();
    if (isEmpty()) return null;

    Node node = root;
    Point2D champion = root.point;
    alternate = true;
    return nearestNode(node, p, champion);
  }

  private Point2D nearestNode(Node node, Point2D p, Point2D champion) {
    if (node == null) return champion;
    Point2D newChampion;
    if (node.point.distanceSquaredTo(p) < champion.distanceSquaredTo(p)) {
      newChampion = node.point;
    }
    else {
      newChampion = champion;
    }
    if (alternate) {
      alternate = false;
      return nearestNode(p.x() > node.point.x() ? node.rt : node.lb, p, newChampion);
    }
    else {
      alternate = true;
      return nearestNode(p.y() > node.point.y() ? node.rt : node.lb, p, newChampion);
    }
  }

}
