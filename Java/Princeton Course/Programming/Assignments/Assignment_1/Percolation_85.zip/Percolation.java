import edu.princeton.cs.algs4.WeightedQuickUnionUF;

  public class Percolation {

  private final int topRootUfIndex;
  private final Node bottomRootNode;
  private final int bottomRootUfIndex;
  private Node[][] grid;
  private WeightedQuickUnionUF weightedQuickUnionUF;
  private int n;

  public Percolation(int n) {
        // create n-by-n grid, with all sites blocked
    if (n < 1 ) throw new IllegalArgumentException("n is out of bounds");
        this.n = n;
        grid = new Node[n][n];
        for(int row=0;row<n;row++){
            for(int col=0;col<n;col++)
            {
                Node o = new Node(row, col, false,false);
                grid[row][col] = o;
            }
        }

      int totalNodes = n * n + 2;
      weightedQuickUnionUF = new WeightedQuickUnionUF(totalNodes);

      topRootUfIndex = n*n;
      bottomRootUfIndex = (n*n) + 1;

      bottomRootNode = new Node(n, n, true, false);
    }

  private void connectOpenNeighbours(int row, int col, int currentNodeUfIndex){

    int newCol = col - 1;
    if(checkLowerBound(newCol))
      tryConnectNeighbour(row, newCol, currentNodeUfIndex);

    newCol = col + 1;
    if(checkUpperBound(newCol))
      tryConnectNeighbour(row, newCol, currentNodeUfIndex);

    int newRow = row - 1;
    if(checkLowerBound(newRow))
      tryConnectNeighbour(newRow, col, currentNodeUfIndex);

    newRow = row + 1;
    if(checkUpperBound(newRow))
      tryConnectNeighbour(newRow, col, currentNodeUfIndex);

    if(isTopVirtualRootNeighbour(row)){
      weightedQuickUnionUF.union(topRootUfIndex, currentNodeUfIndex);
    }

    if(isBottomVirtualRootNeighbour(row)){
      weightedQuickUnionUF.union(bottomRootUfIndex, currentNodeUfIndex);
    }

  }

    private void setOpenNeighboursFull(int row, int col){

      int newCol = col - 1;
      if(checkLowerBound(newCol)) {
        setFull(row, newCol);
      }

      newCol = col + 1;
      if(checkUpperBound(newCol)){
        setFull(row, newCol);
      }

      int newRow = row - 1;
      if(checkLowerBound(newRow)){
        setFull(newRow, col);
      }

      newRow = row + 1;
      if(checkUpperBound(newRow)){
        setFull(newRow,col);
      }

      if(isBottomVirtualRootNeighbour(row)){
        bottomRootNode.setFull();
      }

    }

    private void setFull(int row, int col) {
      Node neighbour = grid[row][col];
      if(neighbour.getOpen() && !neighbour.getFull()) {
        neighbour.setFull();
        setOpenNeighboursFull(row, col);
      }
    }

    private boolean checkUpperBound(int newRow) {
      return newRow <= n-1;
    }

    private boolean checkLowerBound(int newCol) {
      return newCol >= 0;
    }

    private boolean isBottomVirtualRootNeighbour(int row) {
    int lastRowNumber = n - 1;
    return row == lastRowNumber;
  }

  private boolean isTopVirtualRootNeighbour(int row) {
    int firstRowNumber = 0;
    return row == firstRowNumber;
  }

  private void tryConnectNeighbour(int row, int col, int currentNodeUfIndex) {
    Node neighbour = grid[row][col];

    if(neighbour.getOpen()) {
      int neighbourUfIndex = getUFIndex(neighbour);

      if(!checkIfNodeAndNeighbourAreConnected(currentNodeUfIndex, neighbourUfIndex)) {
        weightedQuickUnionUF.union(currentNodeUfIndex, neighbourUfIndex);
      }
    }
  }

  public void open(int row, int col) {
    // open site (row, col) if it is not open already
    row -= 1;
    col -= 1;

    if (row < 0 || row >=n  || col < 0 || col >= n) throw new IllegalArgumentException("row index i out of bounds");

    Node currentNode = grid[row][col];
    int currentNodeUfIndex = getUFIndex(currentNode);

    currentNode.setOpen();
    connectOpenNeighbours(row, col, currentNodeUfIndex);

    if(checkIfNodeComponentHasTopVirtualRoot(currentNodeUfIndex)) {
      currentNode.setFull();
      setOpenNeighboursFull(row, col);
    }

  }

  private boolean checkIfNodeAndNeighbourAreConnected(int currentNodeUfIndex, int neighbourUfIndex) {
    return weightedQuickUnionUF.connected(currentNodeUfIndex, neighbourUfIndex);
  }

  private boolean checkIfNodeComponentHasTopVirtualRoot(int currentNodeUfIndex) {
    return weightedQuickUnionUF.connected(currentNodeUfIndex,topRootUfIndex);
  }

  private int getUFIndex(Node o){
    int index;
    int row = o.getRow();
    int col = o.getCol();

    if(row == -1 && col == -1)
      return topRootUfIndex;
    if(row==n && col==n)
      return bottomRootUfIndex;

    index = (row*n + col) ;
    return index;
  }

  public boolean isFull(int row, int col) {
    row -= 1;
    col -= 1;
    if (row < 0 || row >=n  || col < 0 || col >= n) throw new IllegalArgumentException("row index i out of bounds");
    Node o = grid[row][col];
    return o.getFull();
  }


  public boolean isOpen(int row, int col) {
      row -= 1;
      col -= 1;
    if (row < 0 || row >=n  || col < 0 || col >= n) throw new IllegalArgumentException("row index i out of bounds");
      Node o = grid[row][col];
      return o.getOpen();
  }

  public int numberOfOpenSites() {
        // number of open sites
        int count = 0;
        for(int i=0;i<n;i++){
            for(int j=0;j<n;j++)
            {
              Node Node = grid[i][j];
              if(Node.getOpen())
                {
                    count += 1;
                }
            }
        }
        return count;
    }

  public boolean percolates() {
        // does the system percolate?
      return (weightedQuickUnionUF.connected(bottomRootUfIndex, topRootUfIndex)) && bottomRootNode.getFull();

  }

}

class Node {
  private int row;
  private int col;
  private boolean open;
  private boolean full;

  Node(int row, int col, boolean open, boolean full) {
    this.row = row;
    this.col = col;
    this.open = open;
    this.full = full;
  }

  void setOpen() {
    this.open = true;
  }

  boolean getOpen()  {
    return open;
  }

  void setFull() {
    this.full = true;
  }

  boolean getFull() {
    return full;
  }

  int getRow() {
    return row;
  }

  int getCol() {
    return col;
  }


}