import edu.princeton.cs.algs4.WeightedQuickUnionUF;

  public class Percolation {

  private final int topRootUfIndex;
  private final int bottomRootUfIndex;
  private boolean[][] gridOpen;
  private boolean[][] gridFull;
  private WeightedQuickUnionUF weightedQuickUnionUF;
  private int n;
  private int numberOfOpenSites;
  private boolean isBottomRootNodeFull;

    public Percolation(int n) {
    if (n < 1 ) throw new IllegalArgumentException("n is out of bounds");
        this.n = n;
        this.numberOfOpenSites = 0;

        gridOpen = new boolean[n+1][n+1];
        gridFull = new boolean[n+1][n+1];
        for(int row=1;row<=n;row++){
            for(int col=1;col<=n;col++)
            {
                gridOpen[row][col] = false;
                gridFull[row][col] = false;
            }
        }

      int totalNodes = n * n + 2;
      weightedQuickUnionUF = new WeightedQuickUnionUF(totalNodes);

      topRootUfIndex = n*n;
      bottomRootUfIndex = (n*n) + 1;
    }

  private void connectOpenNeighbours(int row, int col, int currentNodeUfIndex){

    int newCol = col - 1;
    if(checkLowerBound(newCol))
      tryConnectNeighbour(row, newCol, currentNodeUfIndex);

    newCol = col + 1;
    if(checkUpperBound(newCol))
      tryConnectNeighbour(row, newCol, currentNodeUfIndex);

    int newRow = row - 1;
    if(checkLowerBound(newRow))
      tryConnectNeighbour(newRow, col, currentNodeUfIndex);

    newRow = row + 1;
    if(checkUpperBound(newRow))
      tryConnectNeighbour(newRow, col, currentNodeUfIndex);

    if(isTopVirtualRootNeighbour(row)){
      weightedQuickUnionUF.union(topRootUfIndex, currentNodeUfIndex);
    }

    if(isBottomVirtualRootNeighbour(row)){
      weightedQuickUnionUF.union(bottomRootUfIndex, currentNodeUfIndex);
    }

  }

    private void setOpenNeighboursFull(int row, int col){

      int newCol = col - 1;
      if(checkLowerBound(newCol)) {
        setFull(row, newCol);
      }

      newCol = col + 1;
      if(checkUpperBound(newCol)){
        setFull(row, newCol);
      }

      int newRow = row - 1;
      if(checkLowerBound(newRow)){
        setFull(newRow, col);
      }

      newRow = row + 1;
      if(checkUpperBound(newRow)){
        setFull(newRow,col);
      }

      if(isBottomVirtualRootNeighbour(row)){
        isBottomRootNodeFull = true;
      }

    }

    private void setFull(int row, int col) {
      boolean isNeighboburOpen = gridOpen[row][col];
      boolean isNeighboburFull = gridFull[row][col];
      if(isNeighboburOpen && !isNeighboburFull) {
        gridFull[row][col] = true;
        setOpenNeighboursFull(row, col);
      }
    }

    private boolean checkUpperBound(int newRow) {
      return newRow <= n;
    }

    private boolean checkLowerBound(int newCol) {
      return newCol >= 1;
    }

    private boolean isBottomVirtualRootNeighbour(int row) {
    int lastRowNumber = n;
    return row == lastRowNumber;
  }

  private boolean isTopVirtualRootNeighbour(int row) {
    int firstRowNumber = 1;
    return row == firstRowNumber;
  }

  private void tryConnectNeighbour(int row, int col, int currentNodeUfIndex) {
    boolean isNeighbourOpen = gridOpen[row][col];

    if(isNeighbourOpen) {
      int neighbourUfIndex = getUFIndex(row,col);

      if(!checkIfNodeAndNeighbourAreConnected(currentNodeUfIndex, neighbourUfIndex)) {
        weightedQuickUnionUF.union(currentNodeUfIndex, neighbourUfIndex);
      }
    }
  }

  public void open(int row, int col) {

    if (row < 1 || row >n  || col < 1 || col > n) throw new IllegalArgumentException("row index i out of bounds");

    int currentNodeUfIndex = getUFIndex(row,col);

    gridOpen[row][col] = true;
    numberOfOpenSites+=1;
    connectOpenNeighbours(row, col, currentNodeUfIndex);

    if(checkIfNodeComponentHasTopVirtualRoot(currentNodeUfIndex)) {
      gridFull[row][col] = true;
      setOpenNeighboursFull(row, col);
    }

  }

  private boolean checkIfNodeAndNeighbourAreConnected(int currentNodeUfIndex, int neighbourUfIndex) {
    return weightedQuickUnionUF.connected(currentNodeUfIndex, neighbourUfIndex);
  }

  private boolean checkIfNodeComponentHasTopVirtualRoot(int currentNodeUfIndex) {
    return weightedQuickUnionUF.connected(currentNodeUfIndex,topRootUfIndex);
  }

  private int getUFIndex(int row, int col){
    int index;

    if(row == -1 && col == -1)
      return topRootUfIndex;
    if(row==n && col==n)
      return bottomRootUfIndex;

    index = ((row-1)*n + col) ;
    return index;
  }

  public boolean isFull(int row, int col) {
    if (row < 1 || row >n  || col < 1 || col > n) throw new IllegalArgumentException("row index i out of bounds");
    return gridFull[row][col];
  }

  public boolean isOpen(int row, int col) {
    if (row < 1 || row >n  || col < 1 || col > n) throw new IllegalArgumentException("row index i out of bounds");
    return gridOpen[row][col];
  }

  public int numberOfOpenSites() {
        return numberOfOpenSites;
    }

  public boolean percolates() {
      return (weightedQuickUnionUF.connected(bottomRootUfIndex, topRootUfIndex)) && isBottomRootNodeFull;
  }

}