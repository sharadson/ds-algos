import edu.princeton.cs.algs4.WeightedQuickUnionUF;

  public class Percolation {

  private final int topRootUfIndex;
  private final int bottomRootUfIndex;
  private boolean[][] gridOpen;
  private boolean[][] gridFull;
  private WeightedQuickUnionUF weightedQuickUnionUF;
  private int n;

  public Percolation(int n) {
    if (n < 1 ) throw new IllegalArgumentException("n is out of bounds");
        this.n = n;
        gridOpen = new boolean[n+1][n+1];
        gridFull = new boolean[n+1][n+1];

        for(int row=1;row<=n;row++){
            for(int col=1;col<=n;col++)
            {
                gridOpen[row][col] = false;
                gridFull[row][col] = false;
            }
        }

      int totalNodes = n * n + 2;
      weightedQuickUnionUF = new WeightedQuickUnionUF(totalNodes);

      topRootUfIndex = n*n;
      bottomRootUfIndex = (n*n) + 1;
    }

  private void processNeighbours(int currentRow, int currentCol, int currentUfIndex) {

    int neighbourCol = currentCol - 1;
    boolean isCurrentNodeFull = gridFull[currentRow][currentCol];

    if(checkLowerBound(neighbourCol)) {
      int neighbourUfIndex = getUFIndex(currentRow,neighbourCol);
      if(gridOpen[currentRow][neighbourCol]) {
        connectOpen(currentUfIndex, neighbourUfIndex);

        if(isCurrentNodeFull && !gridFull[currentRow][neighbourCol])
          setFull(currentRow, neighbourCol, neighbourUfIndex);
      }
    }

    neighbourCol = currentCol + 1;
    if(checkUpperBound(neighbourCol)) {
      int neighbourUfIndex = getUFIndex(currentRow,neighbourCol);
      if(gridOpen[currentRow][neighbourCol]) {
        connectOpen(currentUfIndex, neighbourUfIndex);

        if(isCurrentNodeFull && !gridFull[currentRow][neighbourCol])
          setFull(currentRow, neighbourCol, neighbourUfIndex);
      }
    }

    int neighbourRow = currentRow - 1;
    if(checkLowerBound(neighbourRow)) {
      int neighbourUfIndex = getUFIndex(neighbourRow,currentCol);
      if(gridOpen[neighbourRow][currentCol]) {
        connectOpen(currentUfIndex, neighbourUfIndex);

        if(isCurrentNodeFull && !gridFull[neighbourRow][currentCol])
          setFull(neighbourRow, currentCol, neighbourUfIndex);
      }
    }

    neighbourRow = currentRow + 1;
    if(checkUpperBound(neighbourRow)) {
      int neighbourUfIndex = getUFIndex(neighbourRow,currentCol);
      if(gridOpen[neighbourRow][currentCol]) {
        connectOpen(currentUfIndex, neighbourUfIndex);

        if(isCurrentNodeFull && !gridFull[neighbourRow][currentCol])
          setFull(neighbourRow, currentCol, neighbourUfIndex);
      }
    }
  }

  private boolean checkUpperBound(int newRow) {
    return newRow <= n;
  }

  private boolean checkLowerBound(int newCol) {
    return newCol >= 1;
  }

  private void connectOpen(int currentNodeUfIndex, int neighbourUfIndex) {
      if(!weightedQuickUnionUF.connected(currentNodeUfIndex, neighbourUfIndex)) {
        weightedQuickUnionUF.union(currentNodeUfIndex, neighbourUfIndex);
      }
  }

    private void setFull(int neighbourRow, int neighbourCol, int neighbourUfIndex) {
        gridFull[neighbourRow][neighbourCol] = true;
        processNeighbours(neighbourRow,neighbourCol,neighbourUfIndex);
    }

    private boolean isBottomVirtualRootNeighbour(int row) {
    int lastRowNumber = n;
    return row == lastRowNumber;
  }

  private boolean isTopVirtualRootNeighbour(int row) {
    int firstRowNumber = 1;
    return row == firstRowNumber;
  }

  public void open(int row, int col) {

    if (row < 1 || row >n  || col < 1 || col > n) throw new IllegalArgumentException("row index i out of bounds");

    int currentNodeUfIndex = getUFIndex(row,col);

    gridOpen[row][col] = true;

    if(isTopVirtualRootNeighbour(row)){
      weightedQuickUnionUF.union(topRootUfIndex, currentNodeUfIndex);
    }

    if(isBottomVirtualRootNeighbour(row)){
      weightedQuickUnionUF.union(bottomRootUfIndex, currentNodeUfIndex);
    }

    gridFull[row][col] = isAnyNeighbourFull(row, col) || weightedQuickUnionUF.connected(topRootUfIndex, currentNodeUfIndex);

    processNeighbours(row, col, currentNodeUfIndex);
  }

    private boolean isAnyNeighbourFull(int currentRow, int currentCol) {

      int neighbourCol = currentCol - 1;
      if(checkLowerBound(neighbourCol) && gridFull[currentRow][neighbourCol]) {
        return true;
      }

      neighbourCol = currentCol + 1;
      if(checkUpperBound(neighbourCol) && gridFull[currentRow][neighbourCol]) {
        return true;
      }

      int neighbourRow = currentRow - 1;
      if(checkLowerBound(neighbourRow) && gridFull[neighbourRow][currentCol]) {
        return true;
      }

      neighbourRow = currentRow + 1;
      return checkUpperBound(neighbourRow) && gridFull[neighbourRow][currentCol];

    }

    private int getUFIndex(int row, int col){
    return ((row-1)*n + (col-1));
  }

  public boolean isFull(int row, int col) {
    if (row < 1 || row >n  || col < 1 || col > n) throw new IllegalArgumentException("row index i out of bounds");
    return gridFull[row][col];
  }

  public boolean isOpen(int row, int col) {
    if (row < 1 || row >n  || col < 1 || col > n) throw new IllegalArgumentException("row index i out of bounds");
    return gridOpen[row][col];
  }

  public int numberOfOpenSites() {
    int numberOfOpenSites = 0;
    for(int row=1;row<=n;row++){
      for(int col=1;col<=n;col++)
      {
        if(gridOpen[row][col])
          numberOfOpenSites+=1 ;
      }
    }
    return numberOfOpenSites;
    }

  public boolean percolates() {
      return (weightedQuickUnionUF.connected(bottomRootUfIndex, topRootUfIndex));
  }

}